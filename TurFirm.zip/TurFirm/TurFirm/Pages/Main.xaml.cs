﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TurFirm.Pages
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        public Main()
        {

            InitializeComponent();

            updateB.Click += (s, e) => Update();
            userName.MouseUp += (s, e) =>
            {

                if (bd.getUser == null) MainWindow.ChangePage(MainWindow.PageType.auth);
                else if(MessageBox.Show("Вы точно хотите выйти?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes) bd.Exit();

                Update();

            };

            Update();

        }

        public void Update()
        {

            var user = bd.getUser;
            userName.Text = user == null ? "Войти" : user.name;

            list.Items.Clear();

            if (added.IsChecked == true)
            {

                var turList = bd.getAddedTurs;

                foreach (var tur in turList)
                {

                    var grid = new Grid();

                    var row1 = new RowDefinition();
                    var row2 = new RowDefinition();
                    var column1 = new ColumnDefinition();
                    var column2 = new ColumnDefinition();

                    row2.Height = new GridLength(2, GridUnitType.Star);
                    column2.Width = new GridLength(9, GridUnitType.Star);

                    grid.RowDefinitions.Add(row1);
                    grid.RowDefinitions.Add(row2);

                    grid.ColumnDefinitions.Add(column1);
                    grid.ColumnDefinitions.Add(column2);

                    var image = new Image();
                    var img = new BitmapImage();
                    img.BeginInit();
                    img.StreamSource = new MemoryStream(tur.Turs.prew);
                    img.EndInit();
                    image.Source = img;
                    image.Width = 80;
                    image.Height = 80;
                    image.Margin = new Thickness(5);

                    Grid.SetRow(image, 0);
                    Grid.SetRowSpan(image, 2);
                    Grid.SetColumn(image, 0);
                    grid.Children.Add(image);

                    var nameT = new TextBlock();
                    nameT.Text = tur.Turs.name;
                    nameT.Padding = new Thickness(5);
                    nameT.FontSize = 18;

                    Grid.SetRow(nameT, 0);
                    Grid.SetColumn(nameT, 1);
                    grid.Children.Add(nameT);

                    var infoT = new TextBlock();
                    infoT.Text = (tur.Turs.info.Length < 50 ? tur.Turs.info : tur.Turs.info.Substring(0, 50) + "...") + $"\n{tur.date.ToShortDateString()} Количество: {tur.count}";
                    infoT.Padding = new Thickness(5);
                    infoT.FontSize = 18;
                    infoT.TextWrapping = TextWrapping.Wrap;

                    Grid.SetRow(infoT, 1);
                    Grid.SetColumn(infoT, 1);
                    grid.Children.Add(infoT);

                    list.Items.Add(grid);

                }

                list.SelectionChanged += (s, e) =>
                {

                    if (list.SelectedIndex == -1) return;

                    if (bd.getUser == null) MainWindow.ChangePage(MainWindow.PageType.auth);
                    else
                    {

                        MainWindow.ChangePage(new TurItem(turList[list.SelectedIndex].Turs));

                    }

                };

            }
            else
            {

                var turList = bd.getTurs;

                foreach (var tur in turList)
                {

                    var grid = new Grid();

                    var row1 = new RowDefinition();
                    var row2 = new RowDefinition();
                    var column1 = new ColumnDefinition();
                    var column2 = new ColumnDefinition();

                    row2.Height = new GridLength(2, GridUnitType.Star);
                    column2.Width = new GridLength(9, GridUnitType.Star);

                    grid.RowDefinitions.Add(row1);
                    grid.RowDefinitions.Add(row2);

                    grid.ColumnDefinitions.Add(column1);
                    grid.ColumnDefinitions.Add(column2);

                    var image = new Image();
                    var img = new BitmapImage();
                    img.BeginInit();
                    img.StreamSource = new MemoryStream(tur.prew);
                    img.EndInit();
                    image.Source = img;
                    image.Width = 80;
                    image.Height = 80;
                    image.Margin = new Thickness(5);

                    Grid.SetRow(image, 0);
                    Grid.SetRowSpan(image, 2);
                    Grid.SetColumn(image, 0);
                    grid.Children.Add(image);

                    var nameT = new TextBlock();
                    nameT.Text = tur.name;
                    nameT.Padding = new Thickness(5);
                    nameT.FontSize = 18;

                    Grid.SetRow(nameT, 0);
                    Grid.SetColumn(nameT, 1);
                    grid.Children.Add(nameT);

                    var infoT = new TextBlock();
                    infoT.Text = tur.info.Length < 50 ? tur.info : tur.info.Substring(0, 50) + "...";
                    infoT.Padding = new Thickness(5);
                    infoT.FontSize = 18;
                    infoT.TextWrapping = TextWrapping.Wrap;

                    Grid.SetRow(infoT, 1);
                    Grid.SetColumn(infoT, 1);
                    grid.Children.Add(infoT);

                    list.Items.Add(grid);

                }

                list.SelectionChanged += (s, e) =>
                {

                    if (list.SelectedIndex == -1) return;

                    if (bd.getUser == null) MainWindow.ChangePage(MainWindow.PageType.auth);
                    else
                    {

                        MainWindow.ChangePage(new TurItem(turList[list.SelectedIndex]));

                    }

                };

            }

        }

    }
}
