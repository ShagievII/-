﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TurFirm.Pages
{
    /// <summary>
    /// Логика взаимодействия для TurItem.xaml
    /// </summary>
    public partial class TurItem : Page
    {
        public TurItem()
        {
            InitializeComponent();

            back.Click += (s, e) => MainWindow.ChangePage(MainWindow.PageType.main);

        }

        public TurItem(Turs tur)
        {

            InitializeComponent();
            
            back.Click += (s, e) => MainWindow.ChangePage(MainWindow.PageType.main);

            title.Text = tur.name;
            info.Text = tur.info;

            int c = 0;

            foreach(var i in bd.getImages(tur.id))
            {

                var image = new Image();
                var img = new BitmapImage();
                img.BeginInit();
                img.StreamSource = new MemoryStream(i);
                img.EndInit();
                image.Source = img;
                image.Width = 320;
                image.Height = 180;
                image.Margin = new Thickness(2);

                Grid.SetColumn(image, c);
                images.ColumnDefinitions.Add(new ColumnDefinition());
                images.Children.Add(image);

                c ++;

            }

            add.Click += (s, e) =>
            {

                var dateTime = date.SelectedDate;
                var countT = count.Text;

                int Count;

                if (dateTime == null || !int.TryParse(countT, out Count)) { MessageBox.Show("Заполните все поля"); return; }

                bd.addTur((DateTime)dateTime, Count, tur.id);

            };

        }

    }
}
