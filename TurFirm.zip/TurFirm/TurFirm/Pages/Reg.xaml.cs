﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TurFirm.Pages
{
    /// <summary>
    /// Логика взаимодействия для Reg.xaml
    /// </summary>
    public partial class Reg : Page
    {
        public Reg()
        {
            InitializeComponent();

            regB.Click += (s, e) =>
            {

                string loginT = login.Text, passT = pass.Password, nameT = name.Text;

                if (loginT == null || passT == null || nameT == null) { MessageBox.Show("Заполните все поля"); return; }

                if (!bd.Reg(nameT, loginT, passT)) MessageBox.Show("Данный логин уже используется");
                else
                {

                    MessageBox.Show("Регистрация прошла успешно!");
                    MainWindow.ChangePage(MainWindow.PageType.main);

                }

            };

            toAuthB.MouseUp += (s, e) => MainWindow.ChangePage(MainWindow.PageType.auth);

        }
    }
}
