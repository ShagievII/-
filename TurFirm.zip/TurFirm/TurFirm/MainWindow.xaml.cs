﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TurFirm.Pages;

namespace TurFirm
{

    public partial class MainWindow : Window
    {

        static Frame mainF;

        static Auth auth;
        static Reg reg;
        static Main main;

        public MainWindow()
        {
            InitializeComponent();

            mainF = MainFraim;

            auth = new Auth();
            reg = new Reg();
            main = new Main();

            ChangePage(PageType.main);

        }

        public static void ChangePage(PageType type)
        {

            switch (type)
            {

                case PageType.auth: mainF.Navigate(auth); break;

                case PageType.reg: mainF.Navigate(reg); break;

                case PageType.main: main.Update(); mainF.Navigate(main); break;

            }

        }

        public static void ChangePage(Page page) => mainF.Navigate(page);

        public enum PageType
        {

            auth,
            reg,
            main,
            info

        }

    }
}
