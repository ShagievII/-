﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurFirm
{
    class bd
    {

        static turBd TurBd;
        static int userId = -1;

        static bd()
        {

            TurBd = new turBd();

        }

        public static bool Auth(string login, string pass)
        {

            var user = TurBd.Users.Where(u => u.login.Equals(login) && u.pass.Equals(pass));
            if (user.Count() == 0) return false;

            userId = user.First().id;
            return true;

        }

        public static bool Reg(string name, string login, string pass)
        {

            if (TurBd.Users.Where(u => u.login.Equals(login)).Count() != 0) return false;

            TurBd.Users.Add(new Users()
            {

                name = name,
                login = login,
                pass = pass

            });
            TurBd.SaveChanges();

            return Auth(login, pass);

        }

        public static Users getUser { get => TurBd.Users.Find(userId); }

        public static void Exit() => userId = -1;

        public static List<Turs> getTurs { get => TurBd.Turs.ToList(); }
        public static List<UserTur> getAddedTurs { get => TurBd.UserTur.Where(t => t.idUser == userId).ToList(); }

        public static List<byte[]> getImages(int id) => TurBd.TurImage.Where(i => i.idTur == id).Select(u => u.image).ToList();

        public static void addTur(DateTime date, int count, int idTur)
        {

            TurBd.UserTur.Add(new UserTur()
            {

                idUser = userId,
                idTur = idTur,
                date = date,
                count = count

            });
            TurBd.SaveChanges();

        }

    }
}
